package com.example.mcalc;

public class MortgageModel {

    private double p;
    private int n;
    private double r;

    public MortgageModel(String p, String a, String i)
    {
     this.p = Double.parseDouble(p);
     this.n = Integer.parseInt(a)*12;
     this.r = (Double.parseDouble(i)/12)/100;
    }


     public String computePayment()
   {
       double ushit = this.p*this.r;
       double cuount = (1-(Math.pow((1+this.r),((-1)*(this.n)))));
       double mortgage = 1;
       mortgage = (ushit)/(cuount);
   return String.format("%,.2f",mortgage);
   //return result;
   }

   public static void main(String[] args)
   {
       MortgageModel myModel = new MortgageModel("700000","25","2.75");
       System.out.println(myModel.computePayment());

       MortgageModel myModel2 = new MortgageModel("300000","20","4.5");
       System.out.println(myModel2.computePayment());
   }
}
