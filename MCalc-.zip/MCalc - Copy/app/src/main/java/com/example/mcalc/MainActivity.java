package com.example.mcalc;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void buttonClicked(View v)
    {
        EditText principalView = (EditText) findViewById(R.id.principleBox);
        String p = principalView.getText().toString();
        EditText AmortizationView = (EditText) findViewById(R.id.AmortizationBox);
        String n = AmortizationView.getText().toString();
        EditText InterestView = (EditText) findViewById(R.id.InterestBox);
        String r = InterestView.getText().toString();

        MortgageModel model = new MortgageModel(p, n, r);
        String MyMortgage = "$"+model.computePayment();

        ((TextView)findViewById(R.id.answer)).setText(MyMortgage);
    }

}
